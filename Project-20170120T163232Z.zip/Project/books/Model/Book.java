package com.saurabh.books.Model;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Saurabh on 11/20/2016.
 */

public class Book {

    @SerializedName("id")
    String id;

    @SerializedName("volumeInfo")
    private VolumeInfo volumeInfo;

    @SerializedName("accessInfo")
    private AccessInfo accessInfo;

    public String getId() {
        return id;
    }

    public VolumeInfo getVolumeInfo() {
        return volumeInfo;
    }

    public AccessInfo getAccessInfo() {
        return accessInfo;
    }
}
