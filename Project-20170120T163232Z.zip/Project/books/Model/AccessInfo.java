package com.saurabh.books.Model;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Saurabh on 12/30/2016.
 */

public class AccessInfo {

    @SerializedName("webReaderLink")
    String webReaderLink;

    @SerializedName("accessViewStatus")
    String accessViewStatus;

    public String getWebReaderLink() {
        return webReaderLink;
    }

    public String getAccessViewStatus() {
        return accessViewStatus;
    }
}
