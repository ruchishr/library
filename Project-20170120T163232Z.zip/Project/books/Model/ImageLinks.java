package com.saurabh.books.Model;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Saurabh on 11/20/2016.
 */

public class ImageLinks {

    @SerializedName("smallThumbnail")
    String smallThumbnail;

    public String getSmallThumbnail() {
        return smallThumbnail;
    }
}
