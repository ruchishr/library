package com.saurabh.books.Model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * Created by Saurabh on 11/20/2016.
 */

public class BookList {

    @SerializedName("totalItems")
    int totalItems;

    List<Book> items;

    public List<Book> getBooks() {
        return items;
    }

    public int getTotalItems() {
        return totalItems;
    }
}
