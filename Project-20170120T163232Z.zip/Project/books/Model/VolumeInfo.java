package com.saurabh.books.Model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * Created by Saurabh on 11/20/2016.
 */

public class VolumeInfo {
    @SerializedName("title")
    String title;

    @SerializedName("publisher")
    String publisher;

    @SerializedName("description")
    String description;

    @SerializedName("pageCount")
    String pageCount;

    @SerializedName("publishedDate")
    String publishedDate;

    @SerializedName("averageRating")
    String averageRating;

    @SerializedName("language")
    String language;

    @SerializedName("authors")
    List<String> authors;

    @SerializedName("categories")
    List<String> categories;

    @SerializedName("imageLinks")
    private ImageLinks imageLinks;

    public String getTitle() {
        return title;
    }

    public String getPublisher() {
        return publisher;
    }

    public String getDescription() {
        return description;
    }

    public String getPageCount() {
        return pageCount;
    }

    public String getPublishedDate() {
        return publishedDate;
    }

    public String getAverageRating() {
        return averageRating;
    }

    public String getLanguage() {
        return language;
    }

    public List<String> getAuthors() {
        return authors;
    }

    public List<String> getCategories() {
        return categories;
    }

    public ImageLinks getImageLinks() {
        return imageLinks;
    }
}
