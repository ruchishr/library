package com.saurabh.books;

import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowManager;

import com.github.paolorotolo.appintro.AppIntro;
import com.github.paolorotolo.appintro.AppIntroFragment;

/**
 * Created by Saurabh on 12/16/2016.
 */

public class DefaultIntro extends AppIntro {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        addSlide(AppIntroFragment.newInstance("Discover", "Search for thousands of books", R.drawable.screen1, Color.parseColor("#00BCD4")));
        addSlide(AppIntroFragment.newInstance("Add books to your library", "Get information about your favorite books and add them to your personal library", R.drawable.screen2, Color.parseColor("#0277BD")));
        addSlide(AppIntroFragment.newInstance("Access everywhere", "Your books are synced across all your devices", R.drawable.screen3, Color.parseColor("#5C6BC0")));
        addSlide(SampleSlide.newInstance(R.layout.intro_register));
        showSkipButton(true);
        setProgressButtonEnabled(true);
        if (Build.VERSION.SDK_INT >= 21) {
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS,
                    WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            getSupportActionBar().hide();
        }
    }

    @Override
    public void onDonePressed() {
        super.onDonePressed();
        finish();
    }

    @Override
    public void onSkipPressed() {
        super.onSkipPressed();
        finish();
    }
}
