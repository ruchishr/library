package com.saurabh.books;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.LayerDrawable;
import android.net.Uri;
import android.os.Build;
import android.support.customtabs.CustomTabsIntent;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.transition.TransitionInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.saurabh.books.Model.FirebaseBook;
import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class DetailsActivity extends AppCompatActivity {

    Button addButton;
    DatabaseReference databaseReference, bookReference;
    String userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        final Intent intent = getIntent();
        final String title = intent.getStringExtra("title");
        final String publisher = intent.getStringExtra("publisher");
        final String smallThumbnail = intent.getStringExtra("smallThumbnail");
        String description = intent.getStringExtra("description");
        String pageCount = intent.getStringExtra("pageCount");
        String publishedDate = intent.getStringExtra("publishedDate");
        String averageRating = intent.getStringExtra("averageRating");
        String language = intent.getStringExtra("language");
        String author = intent.getStringExtra("author");
        String category = intent.getStringExtra("categories");
        final String webReaderLink = intent.getStringExtra("webReaderLink");
        String accessViewStatus = intent.getStringExtra("accessViewStatus");
        final String id = intent.getStringExtra("id");

        setTitle(title);

        TextView titleDetails = (TextView) findViewById(R.id.titleDetails);
        ImageView thumbnailDetails = (ImageView) findViewById(R.id.thumbnailDetails);
        TextView authorDetails = (TextView) findViewById(R.id.authorDetails);
        TextView descriptionDetails = (TextView) findViewById(R.id.descriptionDetails);
        TextView publisherDetails = (TextView) findViewById(R.id.publisherDetails);
        TextView pages = (TextView) findViewById(R.id.pages);
        TextView publishDate = (TextView) findViewById(R.id.publish_date);
        TextView languageDetails = (TextView) findViewById(R.id.language);
        TextView categoryDetails = (TextView) findViewById(R.id.categoryDetails);
        final Button btnPreview = (Button) findViewById(R.id.btn_preview);

        if (accessViewStatus.equals("SAMPLE")) {
            btnPreview.setVisibility(View.VISIBLE);
            btnPreview.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
                    CustomTabsIntent customTabsIntent = builder.setToolbarColor(getResources().getColor(R.color.colorPrimary)).build();
                    customTabsIntent.launchUrl(DetailsActivity.this, Uri.parse(webReaderLink + "#f=true"));
                }
            });
        }

        titleDetails.setText(title);
        authorDetails.setText(author);
        publisherDetails.setText(Html.fromHtml("<b>Publisher:</b> " + publisher));

        if (description != null) {
            descriptionDetails.setText(description);
        } else {
            descriptionDetails.setText("Synopsis not available");
            descriptionDetails.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_warning, 0, 0, 0);
            descriptionDetails.setCompoundDrawablePadding(5);
        }

        if (pageCount != null) {
            pages.setText(Html.fromHtml("<b>Pages:</b> " + pageCount));
        } else {
            pages.setVisibility(View.GONE);
        }

        if (!category.isEmpty()) {
            categoryDetails.setText(Html.fromHtml("<b>Category:</b> " + category));
        } else {
            categoryDetails.setVisibility(View.GONE);
        }

        Locale locale = new Locale(language);
        languageDetails.setText(Html.fromHtml("<b>Language:</b> " + locale.getDisplayLanguage()));

        RatingBar ratingBar = (RatingBar) findViewById(R.id.ratingBar);
        if (averageRating != null) {
            LayerDrawable stars = (LayerDrawable) ratingBar.getProgressDrawable();
            stars.getDrawable(2).setColorFilter(Color.YELLOW, PorterDuff.Mode.SRC_ATOP);
            float f = Float.parseFloat(averageRating);
            ratingBar.setRating(f);
        } else {
            ratingBar.setVisibility(View.GONE);
        }

        if (publishedDate != null && publishedDate.length() > 8) {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
            Date date = null;
            try {
                date = sdf.parse(publishedDate);
            } catch (Exception e) {
                e.printStackTrace();
            }
            SimpleDateFormat formatter = new SimpleDateFormat("dd MMM, yyyy");
            String newFormat = formatter.format(date);
            publishDate.setText(Html.fromHtml("<b>Published on:</b> " + newFormat));
        } else if (publishedDate != null && publishedDate.length() == 4) {
            publishDate.setText(Html.fromHtml("<b>Published in:<b/> " + publishedDate));
        } else {
            publishDate.setVisibility(View.GONE);
        }

        if (smallThumbnail != null) {
            Picasso.with(this)
                    .load(smallThumbnail)
                    .fit()
                    .into(thumbnailDetails);
        } else {
            Picasso.with(this)
                    .load(R.drawable.no_cover)
                    .fit()
                    .into(thumbnailDetails);
        }

        addButton = (Button) findViewById(R.id.btn_add);
        FirebaseAuth auth = FirebaseAuth.getInstance();
        final FirebaseUser user = auth.getCurrentUser();
        databaseReference = FirebaseDatabase.getInstance().getReference();
        if (FirebaseAuth.getInstance().getCurrentUser() == null) {

        } else {
            userId = user.getUid();
        }

        bookReference = FirebaseDatabase.getInstance().getReference();
        if (FirebaseAuth.getInstance().getCurrentUser() != null) {
            bookReference.child("users").child(userId).child("items").orderByChild("id").equalTo(id).addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    if (dataSnapshot.exists()) {
                        addButton.setBackgroundColor(Color.WHITE);
                        addButton.setText("Added");
                        addButton.setTextColor(getResources().getColor(R.color.colorAccent));
                        addButton.setEnabled(false);
                    }
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });
        }

        thumbnailDetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String link = intent.getStringExtra("smallThumbnail");
                if (link != null) {
                    link = link.replace("zoom=2", "zoom=4");
                    Intent i = new Intent(DetailsActivity.this, FullThumbnailActivity.class);
                    i.putExtra("link", link);
                    startActivity(i);
                }
            }
        });

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (FirebaseAuth.getInstance().getCurrentUser() == null) {
                    Toast.makeText(DetailsActivity.this, "Login to add books", Toast.LENGTH_SHORT).show();
                } else {
                    final FirebaseBook firebaseBook = new FirebaseBook();
                    firebaseBook.setUid(databaseReference.child("users").child(userId).child("items").push().getKey());
                    firebaseBook.setTitle(title);
                    firebaseBook.setSmallThumbnail(smallThumbnail);
                    firebaseBook.setId(id);
                    databaseReference.child("users").child(userId).child("items").child(firebaseBook.getUid()).setValue(firebaseBook);

                    addButton.setBackgroundColor(Color.WHITE);
                    addButton.setText("Added");
                    addButton.setTextColor(getResources().getColor(R.color.colorAccent));
                    addButton.setEnabled(false);

                    Snackbar.make(view, "Book added", Snackbar.LENGTH_LONG)
                            .setAction("UNDO", new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    databaseReference.child("users").child(userId).child("items").child(firebaseBook.getUid()).removeValue();
                                    Snackbar.make(view, "Book removed", Snackbar.LENGTH_LONG).show();
                                    addButton.setBackgroundColor(getResources().getColor(R.color.colorAccent));
                                    addButton.setText("Add");
                                    addButton.setTextColor(Color.WHITE);
                                    addButton.setEnabled(true);
                                }
                            })
                            .show();
                }
            }
        });

        if (Build.VERSION.SDK_INT >= 21) {
            getWindow().setSharedElementEnterTransition(TransitionInflater.from(this).inflateTransition(R.transition.shared_element_transition));
            thumbnailDetails.setTransitionName("thumbnailTransition");
            titleDetails.setTransitionName("titleTransition");
            authorDetails.setTransitionName("publisherTransition");
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }}
