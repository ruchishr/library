package com.saurabh.books.Retrofit;

import com.saurabh.books.Model.BookList;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

/**
 * Created by Saurabh on 11/20/2016.
 */

public interface BookApiService {
    @GET("/books/v1/volumes")
    Call<BookList> fetchBooks(@Query("q") String tags, @Query("maxResults") String num, @Query("startIndex") int index);
}
