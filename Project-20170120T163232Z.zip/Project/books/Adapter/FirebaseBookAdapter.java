package com.saurabh.books.Adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.support.v4.graphics.drawable.DrawableCompat;
import android.support.v7.graphics.Palette;
import android.support.v7.widget.PopupMenu;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.saurabh.books.Model.FirebaseBook;
import com.saurabh.books.R;
import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;

import java.util.List;

/**
 * Created by Saurabh on 12/7/2016.
 */

public class FirebaseBookAdapter extends RecyclerView.Adapter<FirebaseBookAdapter.FirebaseBookViewHolder> {

    private Context context;
    private List<FirebaseBook> firebaseBooks;
    DatabaseReference databaseReference;
    String userId;

    public class FirebaseBookViewHolder extends RecyclerView.ViewHolder {
        public TextView title;
        public ImageView thumbnail, overflow;

        public FirebaseBookViewHolder(View view) {
            super(view);
            title = (TextView) view.findViewById(R.id.firebaseTitle);
            thumbnail = (ImageView) view.findViewById(R.id.firebaseThumbnail);
            overflow = (ImageView) view.findViewById(R.id.firebaseOverflow);
        }
    }

    public FirebaseBookAdapter(Context context, List<FirebaseBook> firebaseBooks) {
        this.context = context;
        this.firebaseBooks = firebaseBooks;
    }

    @Override
    public FirebaseBookViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.firebase_book_item, parent, false);
        return new FirebaseBookViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final FirebaseBookViewHolder holder, int position) {
        final FirebaseBook firebaseBook = firebaseBooks.get(position);
        holder.title.setText(firebaseBook.getTitle());
        Picasso.with(context)
                .load(firebaseBook.getSmallThumbnail())
                .fit()
                .into(holder.thumbnail, new Callback() {
                    @Override
                    public void onSuccess() {
                        Bitmap bitmap = ((BitmapDrawable)holder.thumbnail.getDrawable()).getBitmap();
                        Palette.from(bitmap).generate(new Palette.PaletteAsyncListener() {
                            public void onGenerated(Palette palette) {
                                Palette.Swatch swatch = palette.getVibrantSwatch();
                                if (swatch != null) {
                                    holder.itemView.setBackgroundColor(swatch.getRgb());
                                    holder.title.setTextColor(swatch.getTitleTextColor());
                                    DrawableCompat.setTint(holder.overflow.getDrawable(), swatch.getBodyTextColor());
                                } else {
                                    holder.itemView.setBackgroundColor(context.getResources().getColor(android.R.color.white));
                                    DrawableCompat.setTint(holder.overflow.getDrawable(), context.getResources().getColor(android.R.color.black));
                                }
                            }
                        });
                    }

                    @Override
                    public void onError() {

                    }
                });
        holder.overflow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PopupMenu popupMenu = new PopupMenu(context, view);
                MenuInflater inflater = popupMenu.getMenuInflater();
                inflater.inflate(R.menu.menu_firebase_book, popupMenu.getMenu());
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        switch (item.getItemId()) {
                            case R.id.action_remove:
                                databaseReference = FirebaseDatabase.getInstance().getReference();
                                FirebaseAuth auth = FirebaseAuth.getInstance();
                                FirebaseUser user = auth.getCurrentUser();
                                userId = user.getUid();
                                databaseReference.child("users").child(userId).child("items").child(firebaseBook.getUid()).removeValue();
                                Toast.makeText(context, "Removed", Toast.LENGTH_SHORT).show();
                                return true;
                            default:
                        }
                        return false;
                    }
                });
                popupMenu.show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return firebaseBooks.size();
    }
}
