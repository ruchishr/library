package com.saurabh.books.Adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.support.v4.app.ActivityOptionsCompat;
import android.support.v4.util.Pair;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.saurabh.books.DetailsActivity;
import com.saurabh.books.Model.Book;
import com.saurabh.books.R;
import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;

import java.util.List;


/**
 * Created by Saurabh on 11/20/2016.
 */

public class BookAdapter extends RecyclerView.Adapter<BookAdapter.BookViewHolder> {

    private List<Book> books;
    private int rowLayout;
    private Context context;

    public BookAdapter(List<Book> books, int rowLayout, Context context) {
        this.books = books;
        this.rowLayout = rowLayout;
        this.context = context;
    }

    @Override
    public BookViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(rowLayout, parent, false);
        return  new BookViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final BookViewHolder holder, final int position) {
        holder.bookTitle.setText(books.get(position).getVolumeInfo().getTitle());
        if (books.get(position).getVolumeInfo().getAuthors() != null) {
            holder.bookAuthor.setText(books.get(position).getVolumeInfo().getAuthors().get(0));
        } else {
            holder.bookAuthor.setText("");
        }
        if (books.get(position).getVolumeInfo().getImageLinks() == null) {
            Picasso.with(context)
                    .load(R.drawable.no_cover)
                    .fit()
                    .into(holder.smallThumbnail, new Callback() {
                        @Override
                        public void onSuccess() {
                            holder.progressBar.setVisibility(View.GONE);
                        }

                        @Override
                        public void onError() {

                        }
                    });
        } else {
            String thumbnail = books.get(position).getVolumeInfo().getImageLinks().getSmallThumbnail();
            thumbnail = thumbnail.replace("zoom=5", "zoom=2");
            Picasso.with(context)
                    .load(thumbnail)
                    .fit()
                    .into(holder.smallThumbnail, new Callback() {
                        @Override
                        public void onSuccess() {
                            holder.progressBar.setVisibility(View.GONE);
                        }

                        @Override
                        public void onError() {

                        }
                    });
        }

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, DetailsActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.putExtra("title", books.get(position).getVolumeInfo().getTitle());
                intent.putExtra("publisher", books.get(position).getVolumeInfo().getPublisher());
                intent.putExtra("description", books.get(position).getVolumeInfo().getDescription());
                intent.putExtra("pageCount", books.get(position).getVolumeInfo().getPageCount());
                intent.putExtra("publishedDate", books.get(position).getVolumeInfo().getPublishedDate());
                intent.putExtra("averageRating", books.get(position).getVolumeInfo().getAverageRating());
                intent.putExtra("language", books.get(position).getVolumeInfo().getLanguage());
                intent.putExtra("webReaderLink", books.get(position).getAccessInfo().getWebReaderLink());
                intent.putExtra("accessViewStatus", books.get(position).getAccessInfo().getAccessViewStatus());
                intent.putExtra("id", books.get(position).getId());
                if (books.get(position).getVolumeInfo().getCategories() != null) {
                    intent.putExtra("categories", books.get(position).getVolumeInfo().getCategories().get(0));
                } else {
                    intent.putExtra("categories", "");
                }
                if (books.get(position).getVolumeInfo().getAuthors() != null) {
                    intent.putExtra("author", books.get(position).getVolumeInfo().getAuthors().get(0));
                } else {
                    intent.putExtra("author", "");
                }
                if (books.get(position).getVolumeInfo().getImageLinks() == null) {
                    intent.putExtra("smallThumbnail", R.drawable.no_cover);
                } else {
                    String thumbnail = books.get(position).getVolumeInfo().getImageLinks().getSmallThumbnail();
                    thumbnail = thumbnail.replace("zoom=5", "zoom=2");
                    intent.putExtra("smallThumbnail", thumbnail);
                }
                if (Build.VERSION.SDK_INT >= 21) {
                    holder.smallThumbnail.setTransitionName("thumbnailTransition");
                    holder.bookTitle.setTransitionName("titleTransition");
                    holder.bookAuthor.setTransitionName("publisherTransition");
                    Pair<View, String> pair1 = Pair.create((View) holder.smallThumbnail, holder.smallThumbnail.getTransitionName());
                    Pair<View, String> pair2 = Pair.create((View) holder.bookTitle, holder.bookTitle.getTransitionName());
                    Pair<View, String> pair3 = Pair.create((View) holder.bookAuthor, holder.bookAuthor.getTransitionName());
                    ActivityOptionsCompat options =  ActivityOptionsCompat.makeSceneTransitionAnimation((Activity) context, pair1, pair2, pair3);
                    context.startActivity(intent, options.toBundle());
                } else {
                    context.startActivity(intent);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return books.size();
    }

    public static class BookViewHolder extends RecyclerView.ViewHolder {
        TextView bookTitle;
        TextView bookAuthor;
        ImageView smallThumbnail;
        Button addButton;
        ProgressBar progressBar;

        public BookViewHolder(View v) {
            super(v);
            bookTitle = (TextView) v.findViewById(R.id.title);
            bookAuthor = (TextView) v.findViewById(R.id.author);
            smallThumbnail = (ImageView) v.findViewById(R.id.smallThumbnail);
            addButton = (Button) v.findViewById(R.id.btn_add);
            progressBar = (ProgressBar) v.findViewById(R.id.search_loading);
        }
    }

}
