package com.saurabh.books;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.saurabh.books.Adapter.BookAdapter;
import com.saurabh.books.Model.Book;
import com.saurabh.books.Model.BookList;
import com.saurabh.books.Retrofit.BookApiService;
import com.saurabh.books.Retrofit.RestClient;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SearchActivity extends AppCompatActivity {

    private static final String TAG = SearchActivity.class.getSimpleName();

    BookApiService bookApiService;
    Button btnNext, btnPrev;
    ImageView noConnection, noResults;
    RecyclerView recyclerView;
    SwipeRefreshLayout swipeRefreshLayout;
    BookAdapter adapter;
    List<Book> books = new ArrayList<>();
    TextView noResultsText, noConnectionText, tryAgain;

    int index = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        final Intent intent = getIntent();
        final String searchTerm = intent.getStringExtra("searchTerm");

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        PreferenceManager.setDefaultValues(this, R.xml.preferences, false);

        bookApiService = RestClient.getClient().create(BookApiService.class);

        noResults = (ImageView) findViewById(R.id.no_results);
        noResultsText = (TextView) findViewById(R.id.no_results_text);
        noConnection = (ImageView) findViewById(R.id.no_connection);
        noConnectionText = (TextView) findViewById(R.id.no_connection_text);
        tryAgain = (TextView) findViewById(R.id.try_again);

        recyclerView = (RecyclerView) findViewById(R.id.bookRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        swipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.swipeRefreshLayout);
        swipeRefreshLayout.setColorSchemeColors(getResources().getColor(R.color.colorAccent));
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                fetchBookList(searchTerm, 0);
                adapter.notifyDataSetChanged();
            }
        });

        adapter = new BookAdapter(books, R.layout.book_item, SearchActivity.this);
        recyclerView.setAdapter(adapter);

        setTitle("Search results for '" + searchTerm + "'");

        fetchBookList(searchTerm, index);

        btnPrev = (Button) findViewById(R.id.btn_prev);
        btnNext = (Button) findViewById(R.id.btn_next);
        btnPrev.setText(R.string.prev);
        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                index = index + 10;
                fetchBookList(searchTerm, index);
                recyclerView.scrollToPosition(0);
                btnPrev.setVisibility(View.VISIBLE);
            }
        });

        btnPrev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                index  = index - 10;
                fetchBookList(searchTerm, index);
                Log.d(TAG, "onClick: " + Integer.toString(index));
                recyclerView.scrollToPosition(0);
                if (index < 10) {
                    btnPrev.setVisibility(View.GONE);
                }
            }
        });

        tryAgain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fetchBookList(searchTerm, 0);
                adapter.notifyDataSetChanged();
            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
        finish();
    }

    private boolean isOnline()	{
        ConnectivityManager cm = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo ni = cm.getActiveNetworkInfo();
        return ni != null && ni.isConnected();
    }

    private void fetchBookList(final String searchTerm, int index) {
        noConnection.setVisibility(View.GONE);
        noConnectionText.setVisibility(View.GONE);
        tryAgain.setVisibility(View.GONE);
        swipeRefreshLayout.setRefreshing(true);
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(SearchActivity.this);
        String num = preferences.getString("pref_num_results", "-1");
        books.clear();
        Call<BookList> call = bookApiService.fetchBooks(searchTerm, num, index);
        call.enqueue(new Callback<BookList>() {
            @Override
            public void onResponse(Call<BookList> call, Response<BookList> response) {
                if (response.body().getTotalItems() == 0) {
                    swipeRefreshLayout.setRefreshing(false);
                    noResults.setVisibility(View.VISIBLE);
                    noResultsText.setVisibility(View.VISIBLE);
                } else {
                    books.addAll(response.body().getBooks());
                    adapter.notifyDataSetChanged();
                    swipeRefreshLayout.setRefreshing(false);
                }
            }

            @Override
            public void onFailure(Call<BookList> call, Throwable t) {
                if (!isOnline()) {
                    noConnection.setVisibility(View.VISIBLE);
                    noConnectionText.setVisibility(View.VISIBLE);
                    tryAgain.setVisibility(View.VISIBLE);
                    swipeRefreshLayout.setRefreshing(false);
                }
                swipeRefreshLayout.setRefreshing(false);
            }
        });
    }
}
